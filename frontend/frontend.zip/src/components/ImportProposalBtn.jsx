import { useRef, useState } from 'react';
import { Button, CircularProgress, Alert, Snackbar } from '@mui/material';
import { UploadOutlined } from '@ant-design/icons';
import { useImportProposals } from 'hooks/useImportProposals';

export default function ImportProposalBtn() {
    const fileInputRef = useRef(null);
    const { importProposals, isLoading } = useImportProposals();
    const [feedbackOpen, setFeedbackOpen] = useState(false);
    const [feedbackMessage, setFeedbackMessage] = useState('');
    const [feedbackSeverity, setFeedbackSeverity] = useState('info');

    const handleButtonClick = () => {
        fileInputRef.current.click();
    };

    const handleFileChange = async (event) => {
        const file = event.target.files[0];
        if (!file) return;

        // Validation
        const validTypes = [
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        ];
        const isValidParams = file.name.endsWith('.xlsx'); // Relaxed mime check as browser might vary, relying on extension + backend strictness

        if (!isValidParams) {
            showFeedback('Apenas arquivos .xlsx são permitidos.', 'error');
            event.target.value = ''; // Reset
            return;
        }

        if (file.size > 10 * 1024 * 1024) { // 10MB
            showFeedback('O arquivo excede o limite de 10MB.', 'error');
            event.target.value = '';
            return;
        }

        // Process
        const result = await importProposals(file);

        if (result && (result.status === 'SUCCESS' || result.status === 'FAILED')) {
            const message = `Status: ${result.status}. Linhas: ${result.total_rows ?? 0}, Sucesso: ${
                result.success_rows ?? 0
            }, Erros: ${result.error_rows ?? 0}.`;
            showFeedback(message, result.status === 'SUCCESS' ? 'success' : 'error');
        } else {
            showFeedback(result?.message || 'Erro na importação.', 'error');
        }

        event.target.value = ''; // Reset input
    };

    const showFeedback = (msg, severity) => {
        setFeedbackMessage(msg);
        setFeedbackSeverity(severity);
        setFeedbackOpen(true);
    };

    const handleCloseFeedback = () => {
        setFeedbackOpen(false);
    };

    return (
        <>
            <input
                type="file"
                ref={fileInputRef}
                style={{ display: 'none' }}
                accept=".xlsx, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                onChange={handleFileChange}
            />
            <Button
                variant="contained"
                startIcon={isLoading ? <CircularProgress size={20} color="inherit" /> : <UploadOutlined />}
                onClick={handleButtonClick}
                disabled={isLoading}
            >
                {isLoading ? 'Importando...' : 'Importar Propostas'}
            </Button>

            <Snackbar open={feedbackOpen} autoHideDuration={6000} onClose={handleCloseFeedback} anchorOrigin={{ vertical: 'top', horizontal: 'center' }}>
                <Alert onClose={handleCloseFeedback} severity={feedbackSeverity} sx={{ width: '100%' }}>
                    {feedbackMessage}
                </Alert>
            </Snackbar>

        </>
    );
}
