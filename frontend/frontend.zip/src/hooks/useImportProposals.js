import { useState } from 'react';
import { API_BASE_URL } from '../config/api';

export const useImportProposals = () => {
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);
    const [success, setSuccess] = useState(null);

    const importProposals = async (file) => {
        setIsLoading(true);
        setError(null);
        setSuccess(null);

        const formData = new FormData();
        formData.append('file', file);

        try {
            const response = await fetch(`${API_BASE_URL}/imports/proposals`, {
                method: 'POST',
                body: formData,
            });

            const data = await response.json();

            if (response.ok) {
                if (data.status === 'SUCCESS') {
                    setSuccess('Importação concluída com sucesso.');
                } else {
                    const msg = data.error_message || 'A importação falhou.';
                    setError(msg);
                }
                return data;
            } else {
                const msg = data?.message || data?.detail || 'Erro desconhecido na importação.';
                setError(msg);
                return { status: 'error', message: msg, errors: [] };
            }
        } catch (err) {
            console.error(err);
            const msg = err.message || 'Erro ao conectar com o servidor.';
            setError(msg);
            return { status: 'error', message: msg, errors: [] };
        } finally {
            setIsLoading(false);
        }
    };

    return { importProposals, isLoading, error, success };
};
