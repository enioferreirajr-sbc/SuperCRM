"""Contracts for import mapping."""
