from __future__ import annotations

from logging.config import fileConfig

from alembic import context
from sqlalchemy import create_engine, pool

from app.models.base import Base
from app.models import proposal  # noqa: F401
from app.models import proposal_detail  # noqa: F401
from app.models import import_batch  # noqa: F401
from app.models import import_mapping  # noqa: F401
from app.models import customer  # noqa: F401
from app.models import customer_recipient  # noqa: F401
from app.models import product  # noqa: F401
from app.models import proposal_type  # noqa: F401
from app.models import team  # noqa: F401
from app.models import owner  # noqa: F401

config = context.config

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        compare_type=True,
    )

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = create_engine(
        config.get_main_option("sqlalchemy.url"),
        poolclass=pool.NullPool,
    )

    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )

        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
